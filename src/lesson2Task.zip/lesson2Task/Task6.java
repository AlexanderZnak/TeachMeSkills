package lesson2Task;

public class Task6 {
    public static void main(String[] args) {
        for (int a = 2; a <= 100; a++)
            if (a % 2 == 0)
                System.out.println(a);
    }
}
