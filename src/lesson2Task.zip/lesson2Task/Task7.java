package lesson2Task;

public class Task7 {
    public static void main(String[] args) {
        int sum = 0;
        for (int a = 1; a <= 99; a++) {
            if (a % 2 != 0)
                sum += a;
        }
        //System.out.println(sum);
    }
}
