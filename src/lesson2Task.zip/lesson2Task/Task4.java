package lesson2Task;

import java.util.Random;

public class Task4 {
    public static void main(String[] args) {
        int a = (int)(Math.random()*10) + 1;
        int b = (int)(Math.random()*10) + 1;
        Math.multiplyExact(a, b);

    }
}
